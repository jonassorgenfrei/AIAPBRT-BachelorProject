thesis-template
===============

LaTeX-Vorlage für Bachelor/Master-Thesis an der FH-Wedel
(Betreuer Ulrich Hoffmann)

PDF erzeugen:

    % cd Thesis
    % pdflatex thesis_main.tex
    % bibtex thesis_main        # optional for bibliography
    % pdflatex thesis_main.tex  # several times

fork & enjoy

